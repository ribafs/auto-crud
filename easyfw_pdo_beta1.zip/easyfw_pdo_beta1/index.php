<?php 	
session_start();
header("Content-Type: text/html;  charset=UTF-8",true);

if (file_exists('includes/config.php.rename')){
	$file = dirname(__FILE__).DIRECTORY_SEPARATOR.'leiaisto.txt';

	$fd = fopen ($file, "r");
	while (!feof ($fd))
	{
	$buffer = fgets($fd, 4096);
	$lines[] = $buffer;
	}
	fclose ($fd);
	foreach($lines as $linha){
		print $linha . '<br>';
	}
	exit;
}

include_once('./includes/config.php'); 
include_once('./includes/header.php');
if(Config::LANG=='br'){
	include_once('./includes/languages/brazilian.php');
}elseif(Config::LANG=='en'){
	include_once('./includes/languages/english.php');
}

$token = md5(uniqid(rand(), true));
$_SESSION['token'] = $token;
$login='';
if(isset($_GET['login'])){
	$login=$_GET['login'];
}
?>
<link rel="stylesheet" href="./includes/template.css" type="text/css" media="screen">

<script type="text/javascript" src="./includes/js/jquery.js"></script>
<script type="text/javascript" src="./includes/js/interface.js"></script>
<style type="text/css">
a{
	color: #99f;
}
a:hover{
	color: #99c;
}
.linksTooltip{
	border: 3px solid #933;
	background-color: #600;
	padding: 10px;
	color: #ccc;
	margin-left: 50px;
}
.inputsTooltip{
	border: 1px solid #000;
	background-color: #444;
	padding: 4px;
	color: #ccc;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	width: 150px;
}
.inputsTooltip #tooltipTitle{
	font-weight: bold;
}
</style>
</head>
<body onLoad="document.frmLogin.login.focus();">
<div id="page" align="center">
	<div id="header"><h1 align="center"><?php print Config::TITLE;?></h1></div>
    <div id="page">
<br><br><br><br><br>
<h2 align=center><?php print $system_access_lng;?></script></h2>
<br><br><br><br><br>
<form method="POST" action="login.php" name="frmLogin" onSubmit="if(login.value =='' || senha.value =='' || captcha.value =='') {alert('<?php print $allrequireds_lng;?>'); login.focus(); return false;};">
<table border="0">
<input type="hidden" name="token" value="<?php echo $token; ?>" />
<tr><td>Login</td><td><input type="text" name="login" size="12" maxlength="12" value="<?php print $login;?>"></td></tr>
<tr><td><?php print $password_lng;?></td><td><input type="password" name="password" size="12" maxlength="12"></td></tr>
<tr><td><?php print $code_lng;?></td><td><img src="./includes/captcha-image.php" /><input type="text" name="captcha" size="4" maxlength="3" value="" title="<?php print $typecode_lng;?>" /></td></tr>
<tr><td></td><td><input type="submit" name="access" class="submit" value="<?php print $access_lng;?>"></td></tr>
</table>
</form>

<script type="text/javascript">
$('a').ToolTip(
	{
		className: 'inputsTooltip',
		position: 'mouse',
		delay: 100
	}
);
$('input').ToolTip(
	{
		className: 'linksTooltip',
		position: 'bottom'
	}
);
</script>
    </div>
</div>
</body>
</html>

