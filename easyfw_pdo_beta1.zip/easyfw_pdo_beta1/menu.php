<?php 	
session_start();
if(!isset($_SESSION['access'])){
	print "Sessão expirou ou acesso negado!";
	exit;
}

include_once('./includes/config.php');
include_once('./includes/header.php');

if(Config::LANG=='br'){
	include_once('./includes/languages/brazilian.php');
}elseif(Config::LANG=='en'){
	include_once('./includes/languages/english.php');
}

include_once('./includes/classes/class.pdo.php');  
$db=new Db();
?>
<link rel="stylesheet" href="./includes/template.css" type="text/css" media="screen">
<pre>




</pre>

<div id="page">
<div id="header"><h1 align="center"><?php print Config::TITLE;?></h1></div>

<?php
include_once('./includes/classes/class.files.php');
$file = new Files();

$tab=$db->tableNames();

print "<div id=\"page\">";
print "<div id=\"menu\">
<pre>




</pre>
";

for($x=0;$x<count($tab);$x++){

	$pk = $db->primaryKey($tab[$x]);
	if(!$pk) print '<b>'.$tab[$x].': '.$pk_required_lng.'</b><br><br>';
	if(isset($_SESSION['admin'])){
		$file->dir_copy('./includes/matrix',$tab[$x]);
		print "<a href=\"$tab[$x]/index.php?table=$tab[$x]\"><b> - ".ucfirst($tab[$x])."</b></a><br>";
	}else{
		if($tab[$x] !='users'){
			print "<a href=\"$tab[$x]/index.php?table=$tab[$x]\"><b> - ".ucfirst($tab[$x])."</b></a><br>";
		}
	}
}
?>

<pre>










</pre>

<div id="footer"><a href="./includes/exit.php"><b>:: <?php print $exit_lng;?> ::</b></a></div>

