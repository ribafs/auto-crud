<?php
session_start();
if(!isset($_SESSION['access'])){
	print 'Session expired or denied access!';
	exit;
}

include_once('../includes/config.php'); 
if(Config::LANG=='br'){
	include_once('../includes/languages/brazilian.php');

}elseif(Config::LANG=='en'){
	include_once('../includes/languages/english.php');
}

include_once('../includes/header.php');
require_once ('../includes/classes/class.pdo.php');
$db=new Db();

$formins='';$next='';

$table=$_GET['table'];
$pk=$db->primaryKey($table);

$sql = "select max($pk) from $table";
$res=$db->query($sql);
$ret=$res->fetch();
$next = $ret[0]+1;

include_once('../includes/includes.php');
if(Config::LANG=='br'){
	print "<script language=\"JavaScript\" src=\"../includes/js/jquery.validate.br.js\" type=\"text/javascript\"></script>";
}elseif(Config::LANG=='en'){
	print "<script language=\"JavaScript\" src=\"../includes/js/jquery.validate.en.js\" type=\"text/javascript\"></script>";
}
?>

<link rel="stylesheet" href="../includes/template.css" type="text/css" media="screen">

<style type="text/css">
* { font-family: Verdana; font-size: 96%; }
label { width: 10em; float: left; }
label.error { float: none; color: red; padding-left: .5em; vertical-align: top; }
p { clear: both; }
.submit { margin-left: 12em; }
em { font-weight: bold; padding-right: 1em; vertical-align: top; }
</style>

<script>
	$(document).ready(function(){
    	$("#frmIns").validate();
		// Add * to label of required fields
		$('label.required').append('&nbsp;<strong>*</strong>&nbsp;');
	});
</script>

<?php 
if(Config::LANG=='br'){
?>
<script>
  jQuery(function($){
	$("#date").mask("99/99/9999");
	$("#fhone").mask("(999) 9999-9999");
  });
</script>
<?php
}elseif(Config::LANG=='en'){
?>
	<script>
	  jQuery(function($){
		$("#date").mask("9999-99-99");
		$("#fhone").mask("(999) 9999-9999");
	  });
	</script>
<?php
}

$fields='';
$sqlt = "select * from $table";
$nf=$db->fieldsCount($sqlt);
$rest = $db->query($sqlt);

for($x=0;$x<$nf;$x++){
	$value='';$style='';$ro='';$class='';$event='';$s='';$m='';$id='';$len='';$tipo='';$mes='';

	$name=$db->fieldName($sqlt,$x);
	$type = $db->fieldType($table,$name);
	$len = $db->fieldLen($table,$name);

	$label=ucfirst($name);
	if($name==$pk && $table !='users') {
		$value = $next; $style="background:#C4BCBC;";$ro="READONLY";
	}elseif($name=='cpf'){
		$class = "required number";$event="minlength='11'";$label='CPF';
	}elseif($name=='nome'){
		$class = "required";
	}elseif($type=='date'){
		$id="date";$class = "required date";
		if(Config::LANG=='br'){
			$label=ucfirst($name);$event="onClick=\"cal.select(document.forms['frmInsert'].$name,'date','dd/MM/yyyy'); return false;\"";
		}elseif(Config::LANG=='en'){
			$label='Birthday';$event="onClick=\"cal.select(document.forms['frmInsert'].$name,'date','yyyy-MM-dd'); return false;\"";
		}
	}elseif($name=='email'){	
		$class = "required email";
	}elseif($name=='tipo'){	
		$tipo = ' <b>t</b> - todos, <b>a</b> - só andares ou <b>p</b> - só proprietários';
	}elseif($name=='mes'){	
		$mes = ' Exemplo: ago2013 (Agosto de 2013)';
	}
	
	if($type=='blob' || $type=='text'){
		$fields .= "<tr><td>$label </td><td><textarea name=\"$name\" rows=\"10\" cols=\"30\"></textarea></td></tr>\n";
	}elseif($name=='credito_liberado'){
		$fields .= "<tr><td>Liberado? </td><td>
<select name=\"credito_liberado\">
  <option value=\"\" selected>Selecione&nbsp;</option>
  <option value=\"s\">Sim&nbsp;</option>
  <option value=\"n\">Não&nbsp;</option>
</select>
</td></tr>\n";
	}else{
		if($name==$pk){
			$fields .= "<tr><td>$label</td><td><input type=\"text\" name=\"$name\" size=\"$len\" maxlength=\"$len\" value=\"$value\" style=\"$style\" $ro></td></tr>\n";
		}elseif($name=='mes'){
			$fields .= "<tr><td><label class=\"$class\">$label </label></td><td><input id=\"$id\" class=\"$class\" type=\"text\" name=\"$name\" size=\"$len\" maxlength=\"$len\" style=\"$style\" $event>$mes</td></tr>\n";		
		}else{
			$fields .= "<tr><td><label class=\"$class\">$label </label></td><td><input id=\"$id\" class=\"$class\" type=\"text\" name=\"$name\" size=\"$len\" maxlength=\"$len\" style=\"$style\" $event>$tipo</td></tr>\n";		
		}
	}
}
?>
<body onLoad="document.frmInsert.descricao.focus();">

<form id="frmIns" name="frmInsert" method="post" action="">
<table>
<span id="pop1" style="position:absolute"></span>
<?php print $fields;?>

<input type="hidden" name="table" value="<?php print $table;?>">
<tr><td>&nbsp;</td><td><input type="submit" class="submit" value="<?php print $insert_lng;?>"></td></tr>
</table>
</form>
</div>
<br>
<div id="footer"><a href="../menu.php"> :: <b>MENU</b></a><a href="./index.php?table=<?php print $table;?>"> :: <b><?php print $return_lng;?></b></a> <a href="../includes/exit.php"> :: <b><?php print $exit_lng;?> ::</b></a></div>

</div><!--End page -->

<?php
if(isset($_POST[$pk])){
	require_once ('../includes/classes/class.validation.php');
	$val = new Validations();

	$tabela = $_POST['table'];
	$msg='';$values='';$fields='';

	foreach($_POST as $field=>$value){
		$tp = $db->fieldType($table,$field);
		if($tp=='date' && Config::LANG=='br'){
			$date = explode('/',$value);
			$value = $date[2].'-'.$date[1].'-'.$date[0];
		}		
		if($field=='cpf') {
			$cpfv = $val->cpf($value);
			if(!$cpfv) die ('<b>CPF inválido!</b><br>');
		}
		if($field=='email') {
			$emailv = $val->email($value);
			if(!$emailv) die ('<b>E-mail inválido!</b><br>');
		}
		if($field != 'table'){
			$fields .="$field,";
			$values .="'$value',";
		}
	}

	$fields = substr($fields, 0, -1);
	$values = substr($values, 0, -1);

	$sql = "insert into $table ($fields) values ($values)";
	$sqlv = $val->sql($sql); 
	if(!$sqlv) $msg .= 'Invalid SQL String!<br>';// Prevenir contra SQL injection

	if($msg != '') die ($msg);

	$ret=$db->query($sql);
	$client = ucfirst(substr($table,0,-1));
	if($ret){
		print "<script>location=\"index.php?table=$table\"</script>";
	}else{
		print "<br><br>".$errorinsert_lng.' '.$registerdup_lng;
	}
}
?>
