<?php
	session_start();
	if(!isset($_SESSION['access'])){
		print 'Session expired or denied access!';
		exit;
	}
	include_once('../includes/config.php'); 
	include_once('../includes/header.php');

	if(Config::LANG=='br'){
		include_once('../includes/languages/brazilian.php');
	}elseif(Config::LANG=='en'){
		include_once('../includes/languages/english.php');
	}

	include_once('../includes/classes/class.pdo.php');
	include_once('../includes/classes/class.paginacao.pdo.php');
	$db=new Db();

	$table = $_GET['table'];
	$pk = $db->primaryKey($table);

	$sql = "SELECT * FROM $table";// ORDER BY $pk";
	$res=$db->query($sql);
	$tbl = "insert.php?table=".$table;
	if($db->rowsCount($sql)==0) {
		print "<script>alert('Nenhum registro encontrado');location='$tbl';</script>";
		exit;
	}

	if(!$res) die('Erro na conexão');
	$color='';$labels='';$field1='';$field2='';$fields='';$edit='';$delete='';$grid='';
?>

	<link rel="stylesheet" href="../includes/template.css" type="text/css" media="screen">

	<div id="page" align="center">
	<div id="header"><h1><?php print $registration_lng . ucfirst($table)?></h1></div>
    <div id="page">

<?php

// Iniciamos a paginacao
$paginacao = new Paginacao_PDO();
$paginacao->sql = $sql;
$paginacao->limite = Config::RPP;// Mudar para 10 RPP
$paginacao->quantidade = Config::LINKS;// Mudar para 10 links

	$camp='';
	print "<br><table border=\"1\">";
	// Display only 2 fields
	for($x=0;$x<4;$x++){
		if($x==2) continue;// Adicionei para exibir Valor
		$fn=$db->fieldName("select * from ".$table,$x);
		if($x==1) $camp = $fn;
		$labels .= "<td><b>".ucfirst($fn)."</td>";
	}

	print "<tr>".$labels."<td colspan=\"2\" align=\"center\"><b>$action_lng</td></tr>\n";

	$res2 = $db->query($paginacao->sql());
	while($row = $res2->fetch()) {
		$r= $row[$pk];
		// autoclave lists
		if($r%2==0) {
			$color='#F9F9EA';
		}else{
			$color='#D8D8C9';
		}
		$pkv=$row[$pk];
		$field1=$row[1];
		$field2=$row[3];// Mudei para mostrar o valor

		$fields = "<tr><td style=\"background:$color\">".$pkv ."</td>".
				"<td style=\"background:$color\">&nbsp;".$field1."&nbsp;</td>".
				"<td style=\"background:$color\">&nbsp;".$field2."&nbsp;</td>";
		$edit = "<td style=\"background:$color\"><a href=\"edit.php?$pk=$pkv&table=$table\">&nbsp;$edit_lng&nbsp;</a></td>";
		$delete = "<td style=\"background:$color\"><a href='#' onClick=\"if(confirm('$delconf_lng' +".
				"'$field1'+'?')){location='delete.php?$pk=$pkv&table=$table'}\">&nbsp;$delete_lng&nbsp;</a></td></tr>\n";

		$grid = $fields.$edit.$delete;
		print $grid;	
	}
	print "</table>\n";

	// Barra de Navegação
	$paginacao->imprimeBarraNavegacao();

?>
	<br><br>
	<a href="./insert.php?table=<?php print $table;?>"><b><?php print $insert_lng;?> <?php print ucfirst($table);?></b></a><br><br>

<form name="frmSearch" method="post" action="../search.php">
<?php
	print "<input name=\"table\" type=\"hidden\" value=\"$table\">";
	if($table=='users'){
		print "Login ".$orpart_lng ."<input name=\"login\"><input type=\"submit\" class=\"submit\" value=\"$search_lng\">";
	}else{
		print ucfirst($camp).$orpart_lng."<input name=\"field\"><input type=\"submit\" class=\"submit\" value=\"$search_lng\">";
	}
?>
</form>
</div>

<div id="footer" align="center"><a href="../menu.php"> :: <b>MENU</b></a><a href="../includes/exit.php"> :: <b><?php print $exit_lng;?> ::</b></a></div>
</div>
