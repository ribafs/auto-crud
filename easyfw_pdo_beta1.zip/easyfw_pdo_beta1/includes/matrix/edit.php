<?php
session_start();
if(!isset($_SESSION['access'])){
	print 'Session expired or denied access!';
	exit;
}
include_once('../includes/config.php'); 
include_once('../includes/header.php');

if(Config::LANG=='br'){
	include_once('../includes/languages/brazilian.php');
}elseif(Config::LANG=='en'){
	include_once('../includes/languages/english.php');
}

require_once ('../includes/classes/class.pdo.php');
$db = new Db();

$formupd='';
$table=$_GET['table'];

$pk=$db->primaryKey($table);
$pkvalue=$_GET[$pk];

$sql = "SELECT * FROM $table WHERE $pk='$pkvalue'";
$res=$db->query($sql);
$ret=$res->fetch();

include_once('../includes/includes.php');
if(Config::LANG=='br'){
	print "<script language=\"JavaScript\" src=\"../includes/js/jquery.validate.br.js\" type=\"text/javascript\"></script>";
}elseif(Config::LANG=='en'){
	print "<script language=\"JavaScript\" src=\"../includes/js/jquery.validate.en.js\" type=\"text/javascript\"></script>";
}

?>

<link rel="stylesheet" href="../includes/template.css" type="text/css" media="screen">

<style type="text/css">
* { font-family: Verdana; font-size: 96%; }
label { width: 10em; float: left; }
label.error { float: none; color: red; padding-left: .5em; vertical-align: top; }
p { clear: both; }
.submit { margin-left: 12em; }
em { font-weight: bold; padding-right: 1em; vertical-align: top; }
</style>

<script>
  $(document).ready(function(){
    $("#frmEdi").validate();
	// Add * to label of required fields
	$('label.required').append('&nbsp;<strong>*</strong>&nbsp;');
  });
</script>

<?php 
if(Config::LANG=='br'){
?>
<script>
  jQuery(function($){
	$("#date").mask("99/99/9999");
	$("#fhone").mask("(999) 9999-9999");
  });
</script>
<?php
}elseif(Config::LANG=='en'){
?>
	<script>
	  jQuery(function($){
		$("#date").mask("9999-99-99");
		$("#fhone").mask("(999) 9999-9999");
	  });
	</script>
<?php
}

$fields='';$value='';$credito='';
$nf=$db->fieldsCount("select * from $table");

$sqlt = "SELECT * FROM ".$table;

$rest=$db->query($sqlt);

for($x=0;$x<$nf;$x++){
	$style='';$ro='';$class='';$event='';$s='';$m='';$id='';$mesobs='';$tipo='';

	$name=$db->fieldName($sqlt,$x);
	$type=$db->fieldType($table,$name);
	$len = $db->fieldLen($table,$name);

	$label=ucfirst($name);
	$value=$ret[$x];

	if($name==$pk) {
		$style='background:#C4BCBC;';$ro='READONLY';
	}elseif($name=='cpf'){
		$class = "required number";$event="minlength='11'";$label='CPF';
	}elseif($name=='nome'){
		$class = "required";
	}elseif($type=='date'){
		if(Config::LANG =='br'){
			$date = explode('-',$value);
			if($date != NULL){
				$value = $date[2].'/'.$date[1].'/'.$date[0];
			}
			$id="date";$label='Nascimento';$event="onClick=\"cal.select(document.forms['frmEdit'].$name,'date','dd/MM/yyyy');return false;\"";
		}else{
			$id="date";$label='Nascimento';$event="onClick=\"cal.select(document.forms['frmEdit'].$name,'date','yyyy-MM-dd');return false;\"";
		}
	}elseif($name=='email'){	
		$class = "required email";
	}elseif($name=='observacao'){	
		$label = 'Observação';
	}elseif($name=='mes'){
		$mesobs = ' Exemplo: ago2013 (Agosto de 2013)';
	}elseif($name=='tipo'){	
		$tipo = ' <b>t</b> - todos, <b>a</b> - só andares ou <b>p</b> - só proprietários';
	}

	if($type=='blob' || $type=='text'){
		$fields .= "<tr><td>$label </td><td><textarea name=\"$name\" rows=\"10\" cols=\"30\">$value</textarea></td></tr>\n";
	}elseif($name !='credito_liberado'){
		$fields .= "<tr><td><label class=\"$class\">$label </label></td><td><input id=\"$id\" class=\"$class\" type=\"text\" name=\"$name\" size=\"$len\" maxlength=\"$len\" value=\"$value\" style=\"$style\" $ro $event>$mesobs $tipo</td></tr>\n";
	}else{
		$credito=true;
	}
}

?>

<form id="frmEdi" name="frmEdit" method="post" action="">
<table>
<?php print $fields;

if($credito){
	print "<tr><td>Liberado? </td><td>
	<select name=\"credito_liberado\" class=\"select\">";
	switch ($ret['credito_liberado']){
		case 's':
		  	print "<option value=\"s\" SELECTED>Sim&nbsp;</option>";
		  	print "<option value=\"n\" >Não&nbsp;</option>";
			break;
		case 'n':
		default:
		  	print "<option value=\"n\" SELECTED>Não&nbsp;</option>";
		  	print "<option value=\"s\" >Sim&nbsp;</option>";
			break;
	}
	print "</select>
	</td></tr>\n";
}
?>

<input type="hidden" name="table" value="<?php print $table;?>">
<tr><td>&nbsp;</td><td><input type="submit" class="submit" value="<?php print $edit_lng;?>"></td></tr>
</table>
</form>
</div>
<br>
<div id="footer"><a href="../menu.php"> :: <b>MENU</b></a><a href="./index.php?table=<?php print $table;?>"> :: <b><?php print $return_lng;?></b></a> <a href="../includes/exit.php"> :: <b><?php print $exit_lng;?> ::</b></a></div>

</div><!--end page -->

<?php

if(isset($_POST[$pk])){
	require_once ('../includes/classes/class.validation.php');
	$val = new Validations();

	$table = $_POST['table'];
	$pk=$db->primaryKey($table);
	$pkvalue = $_POST[$pk];

	$msg='';
	$edit='';

	foreach($_POST as $field=>$value){
		$tp = $db->fieldType($table,$field);
		if($tp=='date' && Config::LANG=='br'){
			$date = explode('/',$value);
			$value = $date[2].'-'.$date[1].'-'.$date[0];
		}		
		if($field=='cpf') {
			$cpfv = $val->cpf($value);
			if(!$cpfv) die ('CPF inválido!<br>');
		}
		if($field=='email') {
			$emailv = $val->email($value);
			if(!$emailv) die ('Invalid e-mail!<br>');
		}
		if($field != 'table' && $field != 'id'){
			if($field == 'observacao'){
				$value = $db->escape($value);
				$edit .="$field='$value',";
			}else{
				$edit .="$field='$value',";
			}
		}
	}

	$edit = substr($edit, 0, -1);

	$sql = "update $table set $edit where $pk='$pkvalue'";

	$sqlv = $val->sql($sql); 
	if(!$sqlv) $msg .= 'Invalid String SQL!<br>';// Prevenir contra SQL injection

	if($msg != '') die ($msg);

	$res=$db->query($sql);
	if(!$res) {
		die ($errorupdate_lng);
	}else{
		print "<script>;location=\"./index.php?table=$table\";</script>";
	}
}
?>
