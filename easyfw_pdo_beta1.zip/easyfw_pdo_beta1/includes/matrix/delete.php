<?php
session_start();
if(!isset($_SESSION['access'])){
	print 'Session expired or denied access!';
	exit;
}
print "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\" />";

include_once('../includes/config.php'); 
if(Config::LANG=='br'){
	include_once('../includes/languages/brazilian.php');
}elseif(Config::LANG=='en'){
	include_once('../includes/languages/english.php');
}

require_once ('../includes/classes/class.pdo.php');
$db=new Db();

$table = $_GET['table'];
$pk = $db->primaryKey($table);
$pkvalue=$_GET[$pk];

$sql = "delete from $table where $pk='$pkvalue'";
$rec=$db->query($sql);

if(!$rec) {
	die ($errordelete_lng);
}else{
	print "<script>alert('$deletereg_lng');location=\"./index.php?table=$table\";</script>";	
}
?>
