<?php
	$pk_required_lng = 'This table dont have primary key. The Easy Framework only works in tables with primary key!';
	$okupdate_lng = 'Registration updated correctly';
	$errorupdate_lng = 'Error on update register';
	$deletereg_lng = 'Register correctly deleted';
	$errordelete_lng = 'Error on delete!';
	$errorinsert_lng = 'Error on insert!';
	$registerdup_lng = 'See if register is duplicated!';
	$orpart_lng = ' or part ';
	$insert_lng = 'Insert ';
	$registration_lng = 'Registration ';
	$retistrationok_lng = ' registration success!';
	$loginerror_lng = 'Login incorrect! ';
	$passerror_lng = 'Incorrect Password! ';
	$codeerror_lng = 'The security code incorrect! ';
	$tryagain_lng = 'Correct and try again!';

	$system_access_lng = 'System Access';
	$access_lng = 'Access';
	$action_lng = 'Action';
	$add_lng = 'Add';
	$all_flds_lng = 'All fields';
	$all_lng = 'Enter all fields, flease!';
	$all2_lng = 'Empty = Return all registers';

	$black_lng = 'Black';
	$border_lng = 'Border';
	$brown_lng = 'Brown';

	$code_lng = 'Code';
	$conf_lng = 'Confirm';
	$endquery_lng = 'End query';

	$delconf_lng = 'Are you sure to want to delete ';
	$del_lng = 'Delete';
	$denied_lng = 'Direct Access denied!';

	$edit_lng = 'Edit';
	$delete_lng = 'Delete';
	$eg_lng = 'Example';
	$emp_lng = 'Empty';
	$error_ins_lng = 'Error: Fail on insert!';
	$error_lng = 'Error in datas. Click in OK, correct and try again!';
	$exit_lng = 'Exit';

	$field_lng = 'Field';
	$filter_lng = 'Filter';
	$allrequireds_lng = 'All fields are requireds';

	$green_lng = 'Green';

	$html_rep_lng = 'HTML and CSS Report';

	$ins_lng = 'Insert';

	$logo_lng = 'Logo';

	$menu_lng = 'Main Menu';
	$msg_lng = 'Generatede files in directory <b>generateds</b> to table ';

	$orderby_lng = 'Order';

	$password_lng = 'Password';

	$query_lng = 'Query';

	$registers_lng = " registers";
	$ret_flds_lng = 'Return Fields';
	$ret_flds_req_lng = 'Please, enter a value to field Return Fields!';
	$rpp_lng = 'Registers per Page';
	$rpt_obs_lng = 'Or enter a complex query, with JOINs in tables of the database ';
	$rpt_html_lng = 'Dinamics Reports in HTML and CSS with break pages';
	$rpt_lng = 'Report Generator, with one or serious tables, JOIN or others resources';
	$rpt_title_lng = 'Report Title';
	$rpt_obs_lng = 'For more complex queries, enter the query directly in field above, with one or more tables, JOIN or other resources';
	$return_lng = "Return";

	$search_lng = 'Search';
	$search1_lng = "Your search return one register.";
	$searchall_lng = "Your search returns ";
	$searchnone_lng = "Your search return none register.<br>Click in OK and try again.";
	$select_lng = 'Select';
	$sel_table_lng = 'Select a Table';

	$table_lng = 'Table';
	$tbl_sel_lng = 'Table selected';
	$typecode_lng = 'Typist code on left!';

	$upd_lng = 'Update';

	$value_lng = 'Value';

	$wellcome_lng = 'Wellcome ';
	$wellcome2_lng = 'Wellcome';
	$next_lng = 'Next';
	$perms_lng = 'Give write permission in "code_gen/generateds" directory, fill the fields and only then click in Next';
?>
