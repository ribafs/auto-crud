<?php
// To improve the safety, copy this file out of the Apache public_html and here only a include_only()
class Config{
	const SGBD = 'pgsql';	// mysql - MySQL or pg - PostgreSQL
	const HOST = 'localhost';
	const USER = 'postgres';
	const PASS = 'postgres';
	const DB = 'cadastro'; // exemplos em português e english: cadastro / register
	const PORT = '5432';
	const LANG = 'br';	// br - Português do Brasil or en - English
	const RPP = 10;
	const LINKS = 10;
	const TITLE = 'Cadastro - Aplicativo de Exemplo';
}
?>
