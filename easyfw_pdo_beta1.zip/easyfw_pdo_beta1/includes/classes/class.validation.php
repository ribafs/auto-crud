<?php
class Validations{
	function email($email) {
		return filter_var($email, FILTER_VALIDATE_EMAIL) && preg_match('/@.+\./', $email);
	}
	// true = 1		false = null
	//$ret= validateEmail('ribafs@gmail.com');

	function str($str) {
		return filter_var($str, FILTER_SANITIZE_STRING);
	}

	function int($int) {
		return filter_var($int, FILTER_VALIDATE_INT);
	}

	function ip($ip) {
		return filter_var($ip, FILTER_VALIDATE_IP);
	}

	function limpar_entrada($input) {

	  $search = array(
    	'@<script[^>]*?>.*?</script>@si',   // Strip out javascript
    	'@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
    	'@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
    	'@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
  	  );
	  $output = preg_replace($search, '', $input);
      return $output;
    }

	function sanitize($input) {
		$output='';
		if (is_array($input)) {
		    foreach($input as $var=>$val) {
		        $output[$var] = sanitize($val);
		    }
		}else{
		    if (get_magic_quotes_gpc()) {
		        $input = stripslashes($input);
		    }
		    $input  = cleanInput($input);
		    $output = mysql_real_escape_string($input);
		}
		return $output;
	}

	function limpar($text){
		$text = strip_tags($text);
		$text = htmlspecialchars($text, ENT_QUOTES);

		return ($text); //output clean text
	}

	function sql($str) {
		if (!is_numeric($str)) {
		    $str = get_magic_quotes_gpc() ? stripslashes($str) : $str;
			if(Config::SGBD=='mysql'){
			    $str = function_exists('mysql_real_escape_string') ? mysql_real_escape_string($str) : mysql_escape_string($str);
			}elseif(Config::SGBD=='pg'){
			    $str = function_exists('pg_escape_string') ? pg_escape_string($str) : pg_escape_string($str);
			}
		}
		return $str;
	}

	function data($dat){
		$data='';
		$data = explode("/","$dat"); // fatia a string $dat em pedados, usando / como referência
		$d = $data[0];
		$m = $data[1];
		$y = $data[2];

		$res = checkdate($m,$d,$y);
		if ($res == 1){
		   return true;
		} else {
		   return false;
		}
	}

	function cpf($cpf){	// Verifiva se o número digitado contém todos os digitos
		// @autor: Moacir Selínger Fernandes @email: hassed@hassed.com
		$cpf = str_pad(ereg_replace('[^0-9]', '', $cpf), 11, '0', STR_PAD_LEFT);
		// Verifica se nenhuma das sequências abaixo foi digitada, caso seja, retorna falso
		if (strlen($cpf) != 11 || $cpf == '00000000000' || $cpf == '11111111111' || $cpf == '22222222222' || $cpf == '33333333333' || $cpf == '44444444444' || $cpf == '55555555555' || $cpf == '66666666666' || $cpf == '77777777777' || $cpf == '88888888888' || $cpf == '99999999999'){
			return false;
		}else{   // Calcula os números para verificar se o CPF é verdadeiro
		    for ($t = 9; $t < 11; $t++) {
		        for ($d = 0, $c = 0; $c < $t; $c++) {
		            $d += $cpf{$c} * (($t + 1) - $c);
		        }
		        $d = ((10 * $d) % 11) % 10;
		        if ($cpf{$c} != $d) {
		            return false;
		        }
		    }
		    return true;
		}
	}

}

?>
