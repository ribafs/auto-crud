<?php

function encrypt($texto,$senha) {
// Ricardo Ferro - _TrAkiNaS_ - #wm - irc.brasnet.org - trakinas.loko@bol.com.br
 for ($i=1; $i<=strlen($texto); $i=$i+1) {
  $caractersenha=ord(substr($senha,$i-1,1));
  $caractertexto=ord(substr($texto,$i-1,1));
  $caracter = $caractertexto + $caractersenha;
  $textocrypt=$textocrypt.chr($caracter);
 }
 return $textocrypt;
}

function decrypt($textocrypt,$senha) {
 for ($i=1; $i<=strlen($textocrypt); $i=$i+1) {
  $caractersenha=(ord(substr($senha,$i-1,1)));
  $caractertexto=ord(substr($textocrypt,$i-1,1));
  $caracter = $caractertexto - $caractersenha ;
  $textodecrypt=$textodecrypt.chr($caracter);
 }
 return $textodecrypt;
}
/* Using
$texto = "Coloque seu texto aki.";
$senha = "sdsfdfdf";
$textocrypt = encrypt($texto,$senha);
$textodecrypt = decrypt($textocrypt,$senha);

echo "Texto: $texto<br>";
echo "Senha: $senha<br>";
echo "Texto Criptografado: $textocrypt<br>";
echo "Texto Descriptografado: $textodecrypt<br>";
*/

?>
