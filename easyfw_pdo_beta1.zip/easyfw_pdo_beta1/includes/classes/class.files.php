<?php
class Files{
	// recursive file copy
	// http://www.php.net/manual/pt_BR/function.copy.php
	function dir_copy($src,$dst) {
		$dir = opendir($src);
		if(!file_exists($dst)){
			@mkdir($dst);
			while(false !== ( $file = readdir($dir)) ) {
				if (( $file != '.' ) && ( $file != '..' )) {
				    if ( is_dir($src . '/' . $file) ) {
				        recurse_copy($src . '/' . $file,$dst . '/' . $file);
				    }
				    else {
				        copy($src . '/' . $file,$dst . '/' . $file);
				    }
				}
			}
		}
		closedir($dir);
	} 
}
?>
