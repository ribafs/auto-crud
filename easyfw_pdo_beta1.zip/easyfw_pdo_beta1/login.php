<?php
	session_start();
	if (!isset($_SESSION['token']) || $_POST['token'] != $_SESSION['token'] || (!isset($_POST['captcha']))){
		print 'Direct Access denied!';
		exit;
	}
	include_once('./includes/config.php'); 
	if(Config::LANG=='br'){
		include_once('./includes/languages/brazilian.php');
	}elseif(Config::LANG=='en'){
		include_once('./includes/languages/english.php');
	}

	include_once('./includes/classes/class.pdo.php'); 
	$db=new Db();

   	$login=trim($_POST['login']);
   	$pass=trim($_POST['password']);  
	$captcha=$_POST['captcha'];
	$cap='';
	if ($_SESSION['captcha'] == trim($captcha)){
		$cap = 'ok';	   		
		$_SESSION['access']=$login;
	}

	$sql="SELECT login,password,admin FROM users WHERE login ='$login'";
	$res = $db->query($sql);
	$ret = $res->fetch();

	$logindb = $ret['login'];
	$passdb = $ret['password'];
	$admin = $ret['admin'];

	if($admin == 's'){
		$_SESSION['admin']= $admin;
	}

	$msg = '';
	$pass=md5($pass);

	if($login == trim($logindb) && $pass == trim($passdb) && $cap == 'ok'){
		header('location: ./menu.php');
	}else{
		if(trim($login) != trim($logindb)){	
			$msg = $loginerror_lng;			
		}
		if(trim($pass) != trim($passdb)){
			$msg .= $passerror_lng;
		}
		if($cap != 'ok'){				
			$msg .= $codeerror_lng;
		}
		if($msg != ''){
			$msg .=$tryagain_lng;
			print "<script>alert(\"$msg\");location=\"index.php?login=$login\"</script>";
		}
	}
?>
