CREATE TABLE users (
  login char(12) PRIMARY KEY,
  password char(32) NOT NULL,
  admin char(1) NOT NULL
);

INSERT INTO users (login, password, admin) VALUES ('admin', md5('admin'), 's');
INSERT INTO users (login, password, admin) VALUES ('user', md5('user'), 'n');

