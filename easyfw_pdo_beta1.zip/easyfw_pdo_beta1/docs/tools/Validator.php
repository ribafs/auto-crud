<?php
/**
 * Copyright (c) 2009 - 2010 Jürgen Gramenz <juergen@gramenz.de>
 * All rights reserved.
 *
 *    This file is part of Zonk! Light Framework.
 *
 *    Zonk! Light Framework is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    Zonk! Light Framework is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details: http://www.gnu.org/licenses/.
 *
 * @package    Zonk! Light Framework
 * @author     Jürgen Gramenz <juergen@gramenz.de>
 * @copyright  Jürgen Gramenz <juergen@gramenz.de>. All rights reserved.
 * @link       http://zonk.gramenz.net
 * @license    GNU General Public License Version 3 (GPL v3)
 */

/**
 * Zonk common validator class for value validator methods
 *
 */
class Zonk_Validator
{
    /**
     * Class key
     *
     */
    const KEY_CLASS             = '__oZonkValidator';

    /**
     * Field data array for validation
     *
     * @var array
     */
    private $_aValidationFields = array();

    /**
     * Setter for field validation data.
     * (field name, field value, validation methods to apply, error messages).
     *
     * @param array $sFieldName  field name
     * @param mixed $mFieldValue field value
     * @param array $aMethods    array of methods as array key and error messages if validation fail as array value
     *
     * @throws Zonk_Exception_System 'EXC_PARAM_FIRST_EMPTY'
     * @throws Zonk_Exception_System 'EXC_PARAM_THIRD_EMPTY'
     * @throws Zonk_Exception_System 'EXC_PARAM_THIRD_FORMAT_WRONG'
     *
     * @return null
     */
    public function setValidationField( $sFieldName, $mFieldValue, array $aMethods )
    {
        $sFieldName  = trim( $sFieldName );

        if ( empty( $sFieldName ) ) {
            throw new Zonk_Exception_System( 'EXC_PARAM_FIRST_EMPTY' );
        }

        if ( empty( $aMethods ) ) {
            throw new Zonk_Exception_System( 'EXC_PARAM_THIRD_EMPTY' );
        }

        $aKeys = array_keys( $aMethods );

        if ( is_numeric( $aKeys[0] ) ) {
            throw new Zonk_Exception_System( 'EXC_PARAM_THIRD_FORMAT_WRONG' );
        }

        $this->_aValidationFields[] = array( $sFieldName, $mFieldValue, $aMethods );
    }

    /**
     * Getter for fields to validate.
     *
     * @return array
     */
    public function getValidationFields()
    {
        return $this->_aValidationFields;
    }

    /**
     * Validate method for form data fields.
     * Field data must have been set previously with setValidationField.
     *
     * @return array
     */
    public function validate()
    {
        $aResults = array( true );
        $aFields  = $this->getValidationFields();

        foreach ( $aFields as $aFieldEntry ) {
            $sFieldName   = $aFieldEntry[0];
            $mValue       = $aFieldEntry[1];
            $aMethodNames = $aFieldEntry[2];

            foreach ( $aMethodNames as $sMethodName => $sErrorMessage ) {
                $blReturn = $this->$sMethodName( $mValue );

                if (    ( 'has' == substr( $sMethodName, 0, 3 ) && true === $blReturn )
                     || ( 'is' == substr( $sMethodName, 0, 2 )  && false === $blReturn )
                   ) {
                    $blError = true;
                } else {
                    $blError = false;
                }

                if ( true === $blError ) {
                    $aResults[0] = false;
                    $aResults[1][$sFieldName][] = $sErrorMessage;
                }
            }
        }

        $this->flushValidationFields();

        return $aResults;
    }

    /**
     * Flushes all validation field data.
     *
     * @return null
     */
    public function flushValidationFields()
    {
        $this->_aValidationFields = array();
    }

    /**
     * Checks whether an input array or string is empty
     * or contains only whitespaces (line breaks, empty strings, tabs etc.)
     *
     * @param mixed $mInput input array or string
     *
     * @return boolean
     */
    public function isEmpty( $mInput )
    {
        if ( is_array( $mInput ) ) {

            if ( empty( $mInput ) ) {
                return true;
            }

            return false;
        } else {
            $mInput = trim( $mInput );

            if ( empty( $mInput ) ) {
                return true;
            }

            return false;
        }
    }

    /**
     * Checks whether an input consists only of alphabetical characters.
     *
     * @param mixed $mInput input string
     *
     * @return boolean
     */
    public function isAlpha( $sInput )
    {
        return (bool) preg_match( '/^[[:alpha:]\pL]+$/iu', $sInput );
    }

    /**
     * Checks whether an input consists only of digits.
     *
     * @param mixed $mInput input string
     *
     * @return boolean
     */
    public function isNumeric( $sInput )
    {
        return (bool) preg_match( '/^[0-9]+$/iu', $sInput );
    }

    /**
     * Checks whether an input consists only of alphabetical characters.
     *
     * @param mixed $mInput input string
     *
     * @return boolean
     */
    public function isAlphaNumeric( $sInput )
    {
        return (bool) preg_match( '/^[[:alnum:]\pL]+$/iu', $sInput );
    }

    /**
     * Checks for email address validity.
     *
     * @param string $sInput input string
     *
     * @return boolean
     */
    public function isEmail( $sInput )
    {
        // RFC 2822
        // $sRegExp = '^[a-z0-9!#$%&\'*\+\/=?^_`{|}~\-]+(?:\.[a-z0-9!#$%&\'*\+\/=?^_`{|}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$';
        $sRegExp = '^[a-z0-9\-_]?[a-z0-9%+&*#\.\-_]+[a-z0-9\-_]?@[a-z]+[a-z\.\-]*\.[a-z]{2,6}$';

        return (bool) preg_match( "/$sRegExp/iu", $sInput );
    }

    /**
     * Checks for IP validity.
     *
     * @param string $sIp IP
     *
     * @return boolean
     */
    public function isIp( $sIp )
    {
        $sRegExp = '^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$';

        return (bool) preg_match( "/$sRegExp/iu", $sIp );
    }

    /**
     * Checks for valid URL.
     * Optional parameter $sProtocol may be used to check for a specific protocol.
     * If $sProtocol is not provided following protocols will match true: HTTP, HTTPS, FTP.
     *
     * @param string $sUrl      URL string
     * @param string $sProtocol optional check for specific protocol
     *
     * @return boolean
     */
    public function isUrl( $sUrl, $sProtocol = null )
    {
        $sUrl = trim( $sUrl );

        if ( empty( $sUrl ) ) {
            return false;
        }

        if ( empty( $sProtocol ) ) {
            $sSearchProtocol = '(http:\/\/|https:\/\/|ftp:\/\/)';
        } else {
            $sSearchProtocol = '(' . strtolower( $sProtocol ) . ':\/\/)';
        }

        $iCount1 = preg_match( "/$sSearchProtocol([\d\w-.]+:[\d\w-.]+@)?([\d\w-.]+?\.(a[cdefgilmnoqrstuwz]|b[abdefghijmnorstvwyz]|c[acdfghiklmnoruvxyz]|d[ejkmnoz]|e[ceghrst]|f[ijkmnor]|g[abdefghilmnpqrstuwy]|h[kmnrtu]|i[delmnoqrst]|j[emop]|k[eghimnprwyz]|l[abcikrstuvy]|m[acdghklmnopqrstuvwxyz]|n[acefgilopruz]|om|p[aefghklmnrstwy]|qa|r[eouw]|s[abcdeghijklmnortuvyz]|t[cdfghjkmnoprtvwz]|u[augkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw]|aero|arpa|biz|com|coop|edu|info|int|gov|mil|museum|name|net|org|pro)(\b|\W(?<!&|=)(?!\.\s|\.{3}).*?))(\s|$)/usmi",
                               $sUrl );

        if ( 0 == $iCount1 ) {
            // if url doesn't contain a protocol we have to append one to check again
            if ( empty( $sProtocol ) ) {
                $sPrefix = 'http://';
            } else {
                $sPrefix = strtolower( $sProtocol ) . '://';
            }

            $iCountCallback = preg_match( "/$sSearchProtocol([\d\w-.]+:[\d\w-.]+@)?([\d\w-.]+?\.(a[cdefgilmnoqrstuwz]|b[abdefghijmnorstvwyz]|c[acdfghiklmnoruvxyz]|d[ejkmnoz]|e[ceghrst]|f[ijkmnor]|g[abdefghilmnpqrstuwy]|h[kmnrtu]|i[delmnoqrst]|j[emop]|k[eghimnprwyz]|l[abcikrstuvy]|m[acdghklmnopqrstuvwxyz]|n[acefgilopruz]|om|p[aefghklmnrstwy]|qa|r[eouw]|s[abcdeghijklmnortuvyz]|t[cdfghjkmnoprtvwz]|u[augkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw]|aero|arpa|biz|com|coop|edu|info|int|gov|mil|museum|name|net|org|pro)(\b|\W(?<!&|=)(?!\.\s|\.{3}).*?))(\s|$)/usmi",
                                          $sPrefix . $sUrl );
            if ( 0 == $iCountCallback ) {
                return false;
            } else {
                return true;
            }
        }

        $iCount2 = preg_match( "/[\.\-:]{2,}/usmi", $sUrl );

        if ( 0 < $iCount2 ) {
            return false;
        }

        $aMatches = array();

        preg_match_all( "/\/{2,}/usmi", $sUrl, $aMatches );

        if ( 1 < count( $aMatches[0] ) ) {
            return false;
        }

        return true;
    }

    /**
     * Tries to filter non-existing person names containing first and last name.
     *
     * @param string $sFirstName first name
     * @param string $sLastName  last name
     *
     * @return boolean
     */
    public function isPersonName( $sFirstName, $sLastName )
    {
        $sFirstName = trim( $sFirstName );
        $sLastName  = trim( $sLastName );

        // first and last name are too short
        if ( 2 > strlen( $sFirstName ) || 2 > strlen( $sLastName ) ) {
            return false;
        }

        // too many vowels or consonants or bad characters
        if (    !$this->isName( $sFirstName )
             || !$this->isName( $sLastName )
           ) {
            return false;
        }

        return true;
    }

    /**
     * Tries to filter non-existing names.
     *
     * @param string $sName first name
     *
     * @return boolean
     */
    public function isName( $sName )
    {
        $sName = trim( $sName );

        // name is too short
        if ( 2 > strlen( $sName ) ) {
            return false;
        }

        // too many vowels or consonants or bad characters
        if (    $this->hasTooManyConsonants( $sName )
             || $this->hasTooManyVowels( $sName )
             || $this->hasBadCharactersInName( $sName )
             || $this->hasOnlyConsonants( $sName )
             || $this->hasOnlyVowels( $sName )
           ) {
            return false;
        }

        return true;
    }

    /**
     * Checks whether a string is UTF-8-encoded or not.
     * Code based upon RegExp from W3C: http://w3.org/International/questions/qa-forms-utf-8.html
     *
     * @see http://w3.org/International/questions/qa-forms-utf-8.html
     *
     * @param $sString string to check
     *
     * @return boolean
     */
    public function isUtf8( $sString )
    {
        return (bool) preg_match( '%^(?:
              [\x09\x0A\x0D\x20-\x7E]            # ASCII
            | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
            |  \xE0[\xA0-\xBF][\x80-\xBF]        # excluding overlongs
            | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
            |  \xED[\x80-\x9F][\x80-\xBF]        # excluding surrogates
            |  \xF0[\x90-\xBF][\x80-\xBF]{2}     # planes 1-3
            | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
            |  \xF4[\x80-\x8F][\x80-\xBF]{2}     # plane 16
        )*$%xs', $sString );
    }

    /**
     * Checks for too many consonants.
     *
     * @param string $sInput       input string
     * @param integer $iConsonants amount of too many successive consonants
     *
     * @return boolean
     */
    public function hasTooManyConsonants( $sInput , $iConsonants = 5 )
    {
        if ( preg_match( '/[bcdfghjklmnpqrstvwxyzß]{' . $iConsonants . ',}/ui', $sInput ) ) {
            return true;
        }

        return false;
    }

    /**
     * Checks if the string contains only consonants.
     *
     * @param string $sInput input string
     *
     * @return boolean
     */
    public function hasOnlyConsonants( $sInput )
    {
        if ( preg_match( '/^[bcdfghjklmnpqrstvwxyzßBCDFGHJKLMNPQRSTVWXYZ]+$/u', $sInput ) ) {
            return true;
        }

        return false;
    }

    /**
     * Checks for too many vowels.
     *
     * @param string $sInput   input string
     * @param integer $iVowels too many vowels
     *
     * @return boolean
     */
    public function hasTooManyVowels( $sInput , $iVowels = 4 )
    {
        // don't use i modifier in regexp! encoding problem ...
        if ( preg_match( '/[aeiouAEIOUäöüÄÖÜ]{' . $iVowels . ',}/u', $sInput ) ) {
            return true;
        }

        return false;
    }

    /**
     * Checks if the string contains only vowels.
     *
     * @param string $sInput input string
     *
     * @return boolean
     */
    public function hasOnlyVowels( $sInput )
    {
        // don't use i modifier in regexp! encoding problem ...
        if ( preg_match( '/^[aeiouAEIOUäöüÄÖÜ]+$/u', $sInput ) ) {
            return true;
        }

        return false;
    }

    /**
     * Checks for bad characters for name strings.
     *
     * @param string $sInput input string
     *
     * @return boolean
     */
    public function hasBadCharactersInName( $sInput )
    {
        if ( preg_match( '@[\:\,\;\_\"\\/\[\]\{\}\%\§\°\^\!\&\=\?\?\`\@\€\*\+\~\|\<\>]@u', $sInput ) ) {
            return true;
        }

        if ( preg_match( '/[\.\-\(\)\']{2,}/u', $sInput ) ) {
            return true;
        }

        return false;
    }
}