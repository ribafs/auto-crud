<?php
session_start();
if(!isset($_SESSION['access'])){
	print 'Session expired or denied access!';
}

include_once('./includes/config.php'); 
if(Config::LANG=='br'){
	include_once('./includes/languages/brazilian.php');
}elseif(Config::LANG=='en'){
	include_once('./includes/languages/english.php');
}

include_once('./includes/header.php');
include_once('./includes/classes/class.pdo.php');
$db=new Db();

$consCon='';
$table = $_POST['table'];
$pk=$db->primaryKey($table);

print "<div id=\"page\" align=\"center\">".
	"<div id=\"header\"><h1>Register ".ucfirst($table)."</h1></div>".
    "<div id=\"page\">";

	$fn=$db->fieldName('select * from '.$table,1);

	if($table=='users'){	
		$login=$_POST['login'];
	}else{
		$field=$_POST['field'];
	}

?><link rel="stylesheet" href="./includes/template.css" type="text/css" media="screen"><?php

	if($table=='users'){
		$strCon = "SELECT * FROM $table WHERE login LIKE '%$login%'";
	}else{
		$strCon = "SELECT * FROM $table WHERE $fn LIKE '%$field%'";
	}

$consCon = $db->query($strCon);
$labels='';

if (!$consCon){
	echo 'Error in query: ' . $db->error();
	exit;
}else{
	if($db->rowsCount($strCon) == 0){
		print "Register not found!<br>";
		print "<a href=\"#\" onClick=\"history.back();\">$return_lng</a>";			
	}else{

		for($x=0;$x<2;$x++){
			$fn=$db->fieldName($strCon,$x);
			$labels .= "<td><b>".ucfirst($fn)."</td>";
		}

		print "<table border=\"1\"><tr>".$labels."</tr>";
		$nr=$db->rowsCount($strCon);

		$cont=0;
		while($cont < $nr){
			$reg = $consCon->fetch();
			$pkvalue=$reg[$pk];
			if($table=='users'){
				print '<tr><td>'.$pkvalue."</td><td><a href=\"$table/edit.php?table=$table&$pk=$pkvalue\">".$reg['login'].'</a></td></tr>';
			}else{
				print '<tr><td>'.$pkvalue."</td><td><a href=\"$table/edit.php?table=$table&$pk=$pkvalue\">".$reg[1].'</a></td></tr>';
			}
			$cont++;
		}
		print '</table>';
	}
}
?>
<pre>



</pre>
<div id="footer"><a href="./menu.php"> :: <b>MENU</b></a><a href="<?php print $table;?>/index.php?table="<?php print $table;?>"> :: <b><?php print $return_lng;?></b></a> <a href="./includes/exit.php"> :: <b><?php print $exit_lng;?> ::</b></a></div>

</div>
